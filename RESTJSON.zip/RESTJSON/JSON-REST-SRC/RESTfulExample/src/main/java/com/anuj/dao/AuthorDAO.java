package com.anuj.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.service.rest.Product;

public class AuthorDAO {
	
	String url = "jdbc:mysql://localhost:3306/";
	  String db = "test";
	  String driver = "com.mysql.jdbc.Driver";
	  String user = "root";
	  String pass = "";
	public String getAuthor() {
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
        findstatement = con.prepareStatement("SELECT * from author order by name");
        //Findstatement.setString(1, Name);  // I have a variable in my file named 'Name' 
        ResultSet rs  = findstatement.executeQuery();
        while (rs.next()) {
        	if(!"".equalsIgnoreCase(result)) {
        		result=result+",";
        	}
        	result = result+"{id:"+rs.getString("author_id");
        	
        	result = result+", name:'"+rs.getString("name")+"'}";
        	
        }
        con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "No Data Found";
		}
		return result; 
		
	}

	public String getAuthorById(String authorId) {
		

		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
        findstatement = con.prepareStatement("SELECT * from author where author_id=?");
        findstatement.setString(1, authorId);  // I have a variable in my file named 'Name' 
        ResultSet rs  = findstatement.executeQuery();
        while (rs.next()) {
        	result = "{id:"+ authorId+", name: "+rs.getString("name")+"}";
        	
        }
        con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "No Data Found";
		}
		return result; 
		
	}

	public String saveAuthor(Product prod) {
		
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
		findstatement = con.prepareStatement("Insert into author(name) values(?)");
		findstatement.setString(1, prod.getAuthorName());
		findstatement.executeUpdate();
        result ="Author created successfully name="+prod.getAuthorName();
        con.close();
		} catch (SQLException e) {
			result ="Error in Creating Author";
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			result ="Error in Creating Author";
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "Error in Creating Author";
		}
		return result; 
		
	}
	
	public String updateAuthor(Product prod) {
		
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
		findstatement = con.prepareStatement("Update author set name=? where author_id=?");
		findstatement.setString(1, prod.getCriteria());
		findstatement.setInt(2, prod.getAuthorId());
		int i=findstatement.executeUpdate();
        
		if(i!=0)
		result ="Author updated successfully to name="+prod.getCriteria();
        
		con.close();
		} catch (SQLException e) {
			result ="Error in Updating Author";
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			result ="Error in Updating Author";
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "Error in Updating Author";
		}
		return result;
	}
	
	public String deleteAuthor(Product prod) {
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
		findstatement = con.prepareStatement("delete from author where author_id=?");
		findstatement.setInt(1, prod.getAuthorId());
		
		int i=findstatement.executeUpdate();
        
		if(i!=0)
		result ="Author delete successfully with id="+prod.getAuthorId();
        
		con.close();
		} catch (SQLException e) {
			result ="Error in Deleting Author";
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			result ="Error in Deleting Author";
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "Error in Deleting Author";
		}
		return result; 
		
	}
}
