package com.anuj.dao;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.service.rest.Product;

public class BookDAO {
	
	  String url = "jdbc:mysql://localhost:3306/";
	  String db = "test";
	  String driver = "com.mysql.jdbc.Driver";
	  String user = "root";
	  String pass = "";
	public String getBooks() {
		
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
        findstatement = con.prepareStatement("SELECT * from books");
        //Findstatement.setString(1, Name);  // I have a variable in my file named 'Name' 
        ResultSet rs  = findstatement.executeQuery();
        while (rs.next()) {
        	if(!"".equalsIgnoreCase(result)) {
        		result=result+",";
        	}
        	result = result + "{id:"+rs.getString("book_id");
        	
        	result = result+", title:'"+rs.getString("name")+"'}";
        	
        }
        con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "No Data Found";
		}
		return result; 
		
	}

	public String getBookById(String id) {
		
		
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
        findstatement = con.prepareStatement("SELECT distinct b.book_id, b.name as book_name,a.author_id , a.name as author_name,c.category_id,c.name as category_name from books b, author a, category c where b.book_id=?");
        findstatement.setString(1, id);  // I have a variable in my file named 'Name' 
        ResultSet rs  = findstatement.executeQuery();
        while (rs.next()) {
        	result = "Books: {id:"+ id+", title: "+rs.getString("book_name")+ ", category: {id:"+rs.getInt("category_id")+", name: "+rs.getString("category_name")+"}, author: {id:"+rs.getInt("author_id")+", name: "+rs.getString("author_name")+"}";
        	
        }
        con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "No Data Found";
		}
		return result; 
		
	}

	public String saveBook(Product prod) {
		
		
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
		ResultSet rs;
		
			int  i=0;
			findstatement = con.prepareStatement("SELECT count(*) from category where name=? ");
			findstatement.setString(1, prod.getCategoryName());
			rs = findstatement.executeQuery();
			
			while (rs.next()) {
				i=rs.getInt("count(*)");
			}
			
			if(i==0) {
				findstatement = con.prepareStatement("Insert into category(name) values(?)");
				findstatement.setString(1, prod.getCategoryName());
				findstatement.executeUpdate();
				
				result = result+"..New Category Created..";
				i=0;
			}
			
			findstatement = con.prepareStatement("SELECT count(*) from author where name=? ");
			findstatement.setString(1, prod.getAuthorName());
			rs = findstatement.executeQuery();
			
			while (rs.next()) {
				i=rs.getInt("count(*)");
			}
			
			if(i==0) {
				findstatement = con.prepareStatement("Insert into author(name) values(?)");
				findstatement.setString(1, prod.getAuthorName());
				findstatement.executeUpdate();
				
				result = result+"..New Author Created..";
				i=0;
			}
			
			findstatement = con.prepareStatement("Insert into books(name,category_id,author_id) values("
					+ "?,(Select category_id from category where name=?), (Select author_id from author where name=?) )");
			findstatement.setString(1, prod.getBookName());
			findstatement.setString(2, prod.getCategoryName());
			findstatement.setString(3, prod.getAuthorName());
			findstatement.executeUpdate();
			result = result+"New Book Created Book="+ prod.getBookName()+" , author="+prod.getAuthorName()+""
					+ " and category= "+prod.getCategoryName();
		
		
        con.close();
		} catch (SQLException e) {
			result="Error in Creating Book";
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			result="Error in Creating Book";
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "Error in Creating Book";
		}
		return result; 
		
	}
	
	public String updateBook(Product prod) {
		
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
		findstatement = con.prepareStatement("Update books set name=? where book_id=?");
		findstatement.setString(1, prod.getCriteria());
		findstatement.setInt(2, prod.getBookId());
		int i=findstatement.executeUpdate();
        
		if(i!=0)
		result ="Book updated successfully to name="+prod.getCriteria();
        
		con.close();
		} catch (SQLException e) {
			result ="Error in Updating Book";
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			result ="Error in Updating Book";
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "Error in Updating Book";
		}
		return result; 
	}
	
	public String deleteBook(Product prod) {
		
		
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
		findstatement = con.prepareStatement("delete from books where book_id=?");
		findstatement.setInt(1, prod.getBookId());
		
		int i=findstatement.executeUpdate();
        
		if(i!=0)
		result ="Book delete successfully with id="+prod.getBookId();
        
		con.close();
		} catch (SQLException e) {
			result ="Error in Deleting Book";
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			result ="Error in Deleting Book";
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "Error in Deleting Book";
		}
		return result; 
		
	}

	public String getBooksByCategory(String categoryId) {
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
        findstatement = con.prepareStatement("SELECT * from books where category_id=?");
        findstatement.setString(1, categoryId);  // I have a variable in my file named 'Name' 
        ResultSet rs  = findstatement.executeQuery();
        while (rs.next()) {
        	if(!"".equalsIgnoreCase(result)) {
        		result=result+",";
        	}
        	result = result + "{id:"+rs.getString("book_id");
        	
        	result = result+", title:'"+rs.getString("name")+"'}";
        	
        	
        }
        con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "No Data Found";
		}
		return result; 
	}

	public String getBooksByAuthor(String authorId) {
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
        findstatement = con.prepareStatement("SELECT * from books where author_id=?");
        findstatement.setString(1, authorId);  // I have a variable in my file named 'Name' 
        ResultSet rs  = findstatement.executeQuery();
        while (rs.next()) {
        	if(!"".equalsIgnoreCase(result)) {
        		result=result+",";
        	}
        	result = result + "{id:"+rs.getString("book_id");
        	
        	result = result+", title:'"+rs.getString("name")+"'}";
        	
        	
        }
        con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "No Data Found";
		}
		return result; 
	}
}
