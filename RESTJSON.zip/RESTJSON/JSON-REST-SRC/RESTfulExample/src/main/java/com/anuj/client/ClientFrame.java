package com.anuj.client;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ClientFrame extends JFrame{

	JLabel lb =null;
	public ClientFrame() {
		super.setName("CLIENT FRAME");
		this.setSize(200, 200);
		this.setVisible(true);
		
		lb = new JLabel();
		this.add(lb);
	}
	
	public void setLabelData(String data) {
		
		this.lb.setText(data);
	}
}
