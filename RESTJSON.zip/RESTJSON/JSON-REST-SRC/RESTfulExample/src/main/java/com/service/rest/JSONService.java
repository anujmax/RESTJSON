package com.service.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import com.anuj.dao.AuthorDAO;
import com.anuj.dao.BookDAO;
import com.anuj.dao.CategoryDAO;

@Path("/json")
public class JSONService {

	@GET
	@Path("/get/bookscategory")
	@Produces("application/json")
	public Response getBooksByCategoryInJSON(@MatrixParam("categoryId") String categoryId) {

		
		String result ="No Data found";
		if(categoryId!=null && !categoryId.equalsIgnoreCase("")) {
			result ="Books: " + new BookDAO().getBooksByCategory(categoryId);
		}
		return Response.status(201).entity(result).build();

	}
	
	@GET
	@Path("/get/booksauthor")
	@Produces("application/json")
	public Response getBooksByAuthorInJSON(@MatrixParam("authorId") String authorId) {

		
		String result ="No Data found";
		if(authorId!=null && !authorId.equalsIgnoreCase("")) {
			result ="Books: " + new BookDAO().getBooksByAuthor(authorId);
		}
		return Response.status(201).entity(result).build();

	}
	
	@GET
	@Path("/get/books")
	@Produces("application/json")
	public Response getBooksInJSON(@MatrixParam("bookId") String bookId) {

		
		String result ="";
		if(bookId!=null && !bookId.equalsIgnoreCase("")) {
			result = new BookDAO().getBookById(bookId);
		}
		else {
			result = "Books : " + new BookDAO().getBooks();
		}
		return Response.status(201).entity(result).build();

	}
	

	@POST
	@Path("/post/book")
	@Consumes("application/json")
	public Response createBookInJSON(Product product) {

		String result = "";
		result = new BookDAO().saveBook(product);
		return Response.status(201).entity(result).build();
		
	}
	
	@PUT
	@Path("/patch/book")
	@Consumes("application/json")
	public Response updateBookInJSON(Product product) {

		String result = "";
		result = new BookDAO().updateBook(product);
		return Response.status(201).entity(result).build();
		
	}
	
	@PUT
	@Path("/delete/book")
	@Consumes("application/json")
	public Response deleteBookInJSON(Product product) {

		String result = "";
		result = new BookDAO().deleteBook(product);
		return Response.status(201).entity(result).build();
		
	}
	
	@GET
	@Path("/get/authors")
	@Produces("application/json")
	public Response getAuthorsInJSON(@MatrixParam("authorId") String authorId) {

		String result ="";
		if(authorId!=null && !authorId.equalsIgnoreCase("")) {
			result = "Authors : "+ new AuthorDAO().getAuthorById(authorId);
		}
		else {
		 result = "Authors : " + new AuthorDAO().getAuthor();
		}
		return Response.status(201).entity(result).build();

	}
	
	@POST
	@Path("/post/author")
	@Consumes("application/json")
	public Response createAuthorInJSON(Product product) {

		String result = "";
		result = new AuthorDAO().saveAuthor(product);
		return Response.status(201).entity(result).build();
		
	}
	@PUT
	@Path("/patch/author")
	@Consumes("application/json")
	public Response updateAuthorInJSON(Product product) {

		String result = "";
		result = new AuthorDAO().updateAuthor(product);
		return Response.status(201).entity(result).build();
		
	}
	
	@PUT
	@Path("/delete/author")
	@Consumes("application/json")
	public Response deleteAuthorInJSON(Product product) {

		String result = "";
		result = new AuthorDAO().deleteAuthor(product);
		return Response.status(201).entity(result).build();
		
	}
	
	@GET
	@Path("/get/categories")
	@Produces("application/json")
	public Response getCategoriesInJSON(@MatrixParam("categoryId") String categoryId) {

		String result ="";
		if(categoryId!=null && !categoryId.equalsIgnoreCase("")) {
			result = "Categories : "+ new CategoryDAO().getCategoryById(categoryId);
		}
		else {
		 result = "Categories : " + new CategoryDAO().getCategory();
		}
		return Response.status(201).entity(result).build();

	}
	
	@POST
	@Path("/post/category")
	@Consumes("application/json")
	public Response createCategoryInJSON(Product product) {

		String result = "";
		result = new CategoryDAO().saveCategory(product);
		return Response.status(201).entity(result).build();
		
	}
	
	@PUT
	@Path("/patch/category")
	@Consumes("application/json")
	public Response updateCategoryInJSON(Product product) {

		String result = "";
		result = new CategoryDAO().updateCategory(product);
		return Response.status(201).entity(result).build();
		
	}
	
	@PUT
	@Path("/delete/category")
	@Consumes("application/json")
	public Response deleteCategoryInJSON(Product product) {

		String result = "";
		result = new CategoryDAO().deleteCategory(product);
		return Response.status(201).entity(result).build();
		
	}
	
		
}