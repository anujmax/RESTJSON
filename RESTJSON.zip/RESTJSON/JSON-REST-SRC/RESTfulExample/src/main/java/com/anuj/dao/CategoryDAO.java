package com.anuj.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.service.rest.Product;

public class CategoryDAO {
	
	String url = "jdbc:mysql://localhost:3306/";
	  String db = "test";
	  String driver = "com.mysql.jdbc.Driver";
	  String user = "root";
	  String pass = "";
	public String getCategory() {
		
		
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
        findstatement = con.prepareStatement("SELECT * from category");
        //Findstatement.setString(1, Name);  // I have a variable in my file named 'Name' 
        ResultSet rs  = findstatement.executeQuery();
        while (rs.next()) {
        	if(!"".equalsIgnoreCase(result)) {
        		result=result+",";
        	}
        	result = result + "{id:"+rs.getString("category_id");
        	
        	result = result+", name:'"+rs.getString("name")+"'}";
        	
        }
        con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "No Data Found";
		}
		return result; 
		
	}

	public String getCategoryById(String categoryId) {
		
		
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
        findstatement = con.prepareStatement("SELECT * from category where category_id=?");
        findstatement.setString(1, categoryId);  // I have a variable in my file named 'Name' 
        ResultSet rs  = findstatement.executeQuery();
        while (rs.next()) {
        	result = "{id:"+ categoryId+", name: "+rs.getString("name")+"}";
        	
        }
        con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "No Data Found";
		}
		return result; 
		
	}

	public String saveCategory(Product prod) {
		
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
		findstatement = con.prepareStatement("Insert into category(name) values(?)");
		findstatement.setString(1, prod.getCategoryName());
		findstatement.executeUpdate();
        result ="Category created successfully name="+prod.getCategoryName();
        con.close();
		} catch (SQLException e) {
			result ="Error in Creating Category";
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			result ="Error in Creating Category";
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "Error in Creating Category";
		}
		return result; 
		
	}
	
	public String updateCategory(Product prod) {
		
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
		findstatement = con.prepareStatement("Update category set name=? where category_id=?");
		findstatement.setString(1, prod.getCriteria());
		findstatement.setInt(2, prod.getCategoryId());
		int i=findstatement.executeUpdate();
        
		if(i!=0)
		result ="Category updated successfully to name="+prod.getCriteria();
        
		con.close();
		} catch (SQLException e) {
			result ="Error in Updating Category";
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			result ="Error in Updating Category";
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "Error in Updating Category";
		}
		return result;
		
	}
	
	public String deleteCategory(Product prod) {
		Connection con=null;
		String result ="";
		try {
			Class.forName(driver);
			con = (Connection) DriverManager.getConnection(url+db, user, pass);
		
		PreparedStatement findstatement;
		findstatement = con.prepareStatement("delete from category where category_id=? ");
		findstatement.setInt(1, prod.getCategoryId());
		
		int i=findstatement.executeUpdate();
        
		if(i!=0)
		result ="Category delete successfully with id="+prod.getCategoryId();
        
		con.close();
		} catch (SQLException e) {
			result ="Error in Deleting Category";
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			result ="Error in Deleting Category";
			e.printStackTrace();
		}
		
		if("".equalsIgnoreCase(result)) {
			return "Error in Deleting Category";
		}
		return result; 
	}
}
