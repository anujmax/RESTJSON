package com.anuj.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ClientGetAuthorbyId {

	// http://localhost:8080/RESTfulExample/json/product/get
	public static String get(String args) {

		try {

			URL url = new URL(
					"http://localhost:8080/RESTfulExample/json/get/authors;authorId="+new Integer(args));
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-Type", "application/json");

			

			//OutputStream os = conn.getOutputStream();
			//os.write(input.getBytes());
			//os.flush();

			if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
				return "No data found";
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			String output;
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {

				System.out.println(output);
				return output;
			}

			conn.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();

		}
		return "No data found";
	}

}