package com.anuj.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ClientGetBooks {

	// http://localhost:8080/RESTfulExample/json/product/get
	public static String get() {

		try {
			
			URL url = new URL(
					"http://localhost:8080/RESTfulExample/json/get/books");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
				return "No Data Found";
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			
			String output;
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				
				System.out.println(output);
				return  output;
			}
			
			conn.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
			
		}
		return "No Data Found";
	}

}