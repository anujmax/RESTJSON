package com.client.gui;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.anuj.client.ClientGetAuthors;
import com.anuj.client.ClientGetBooks;

public class ClientGetAuthorsPanel extends JPanel{
	JButton okButton = new JButton("GET");
	public ClientGetAuthorsPanel()
	{
		
		
		this.setVisible(true);
		this.setSize(400, 200);
		this.setLayout(new FlowLayout());
		this.add(okButton);
		
		okButton.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseClicked(java.awt.event.MouseEvent e) {
		    	
		    	JOptionPane.showMessageDialog(null, ClientGetAuthors.get());
		    }
		});
		
	}

	

}
