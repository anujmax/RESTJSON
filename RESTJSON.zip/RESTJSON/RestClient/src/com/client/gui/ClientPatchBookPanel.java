package com.client.gui;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.anuj.client.ClientPatchBook;

public class ClientPatchBookPanel extends JPanel{
	JButton okButton = new JButton("PATCH");
	JTextField input = new JTextField("book id");
	JTextField input1 = new JTextField("new name");
	public ClientPatchBookPanel()
	{
		
		
		this.setVisible(true);
		this.setSize(400, 200);
		this.setLayout(new FlowLayout());
		this.add(input);
		this.add(input1);
		this.add(okButton);
		
		okButton.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseClicked(java.awt.event.MouseEvent e) {
		    	if(input.getText().equalsIgnoreCase("") || input1.getText().equalsIgnoreCase(""))
		    		JOptionPane.showMessageDialog(null, "Enter Data");
		    	else
		    	JOptionPane.showMessageDialog(null, ClientPatchBook.patch(input.getText(), input1.getText()));
		    }
		});
		
		
	}

	

}
