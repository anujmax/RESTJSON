package com.client.gui;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.anuj.client.ClientDeleteBook;

public class ClientDeleteBookPanel extends JPanel{
	JButton okButton = new JButton("DELETE");
	JTextField input = new JTextField("book id");
	public ClientDeleteBookPanel()
	{
		
		
		this.setVisible(true);
		this.setSize(400, 200);
		this.setLayout(new FlowLayout());
		this.add(input);
		this.add(okButton);
		
		okButton.addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseClicked(java.awt.event.MouseEvent e) {
		    	if(input.getText().equalsIgnoreCase(""))
		    		JOptionPane.showMessageDialog(null, "Enter Data");
		    	else
		    	JOptionPane.showMessageDialog(null, ClientDeleteBook.delete(input.getText()));
		    }
		});
		
	}

	

}
