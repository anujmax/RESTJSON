package com.client.gui;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

import com.anuj.client.ClientDeleteBook;

public class MainClientFrame extends JFrame{
	
	public MainClientFrame(String title)
	{
		super(title);

		this.setVisible(true);
		this.setSize(500, 500);
		this.setResizable(false);
		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		JTabbedPane tabbedPane = new JTabbedPane();
		tabbedPane.addTab("DeleteAuthor", new ClientDeleteAuthorPanel());
		tabbedPane.addTab("DeleteBook", new ClientDeleteBookPanel());
		tabbedPane.addTab("DeleteCategory", new ClientDeleteCategoryPanel());
		tabbedPane.addTab("GetAuthorById", new ClientGetAuthorByIdPanel());
		tabbedPane.addTab("GetAuthors", new ClientGetAuthorsPanel());
		tabbedPane.addTab("GetBookById", new ClientGetBookByIdPanel());
		tabbedPane.addTab("GetBooks", new ClientGetBooksPanel());
		tabbedPane.addTab("GetBooksbyAuthor", new ClientGetBooksByAuthorPanel());
		tabbedPane.addTab("GetBooksbyCategoy", new ClientGetBooksByCategoryPanel());
		tabbedPane.addTab("GetCategories", new ClientGetCategoriesPanel());
		tabbedPane.addTab("GetCategoryById", new ClientGetCategoryByIdPanel());
		tabbedPane.addTab("PatchAuthor", new ClientPatchAuthorPanel());
		tabbedPane.addTab("PatchBook", new ClientPatchBookPanel());
		tabbedPane.addTab("PatchCategory", new ClientPatchCategoryPanel());
		tabbedPane.addTab("PostAuthor", new ClientPostAuthorPanel());
		tabbedPane.addTab("PostBook", new ClientPostBookPanel());
		tabbedPane.addTab("PostCategory", new ClientPostCategoryPanel());
		
		this.add(tabbedPane);
		
	}

	public static void main(String[] args)
	{
		SwingUtilities.invokeLater(new Runnable(){ public void run(){

			new MainClientFrame("Main Client Frame");

		}});

	}

}
